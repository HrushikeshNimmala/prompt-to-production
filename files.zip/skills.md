# UC-0A: Complaint Classifier — skills.md

## Skill: classify_complaint

### What this skill does
Takes a raw complaint text string and returns a structured classification with category, severity level, and routing note.

### Input
- `complaint_text` (str): The raw complaint as submitted by the citizen.

### Output
A JSON object with exactly three keys:
- `category`: One of [Roads, Sanitation, Water, Electricity, Infrastructure, Safety, Public Spaces, Health]
- `severity`: One of [HIGH, MEDIUM, LOW]
- `routing_note`: A single sentence explaining which department and why.

### Severity triggers (mandatory)
The classifier MUST assign HIGH if the complaint text contains any of the following signals:
- Injury or bodily harm: "injured", "hurt", "wounded", "hospitalised", "bitten", "attacked"
- Risk to children: "child", "children", "student", "school"
- Proximity to critical facility: "hospital", "clinic", "dispensary"
- Structural danger: "collapsed", "fallen", "broken structure", "open manhole"
- Life risk phrasing: "almost hit", "near miss", "dangerous", "risk of death"

### Edge cases handled
- Complaint mentions both minor and major issues → classify based on the most severe element.
- Complaint is vague but mentions a location near a school → assume HIGH.
- Multiple categories implied → pick the primary/root cause category.

### CRAFT test checklist
- [ ] Complaint with "child" in text → severity must be HIGH
- [ ] Complaint with "hospitalised" → severity must be HIGH
- [ ] Garbage complaint with no urgency markers → severity is MEDIUM if >5 days, LOW otherwise
- [ ] Output is valid JSON with exactly 3 keys
- [ ] No extra text or explanation outside the JSON block
