"""
UC-0C: Number That Looks Right
Reads ward_budget.csv and computes per-ward per-category budget growth
and utilisation. Writes growth_output.csv.

Commit: UC-0C Fix silent aggregation: no scope in enforcement → restricted to
        per-ward per-category only; added data_missing flag and exact rounding.
"""

import csv
import sys
from collections import defaultdict

# ── Configuration ──────────────────────────────────────────────────────────────
INPUT_FILE  = "data/budget/ward_budget.csv"
OUTPUT_FILE = "uc-0c/growth_output.csv"

OUTPUT_FIELDS = [
    "ward", "category",
    "allocated_2023", "spent_2023",
    "allocated_2024", "spent_2024",
    "pct_growth", "utilisation_2023", "flag"
]


def load_budget_data(filepath: str) -> dict:
    """
    Load CSV into a nested dict: data[ward][category][year] = {allocated, spent}
    """
    data = defaultdict(lambda: defaultdict(dict))
    with open(filepath, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            ward     = row["ward"].strip()
            category = row["category"].strip()
            year     = int(row["year"].strip())
            allocated = float(row["allocated_budget"].strip())
            spent     = float(row["spent_budget"].strip())
            data[ward][category][year] = {
                "allocated": allocated,
                "spent": spent
            }
    return data


def compute_growth(data: dict) -> list:
    """
    For each ward+category pair, compute pct_growth and utilisation_2023.
    Strictly per-ward per-category — no cross-aggregation.
    """
    results = []

    for ward in sorted(data.keys()):
        for category in sorted(data[ward].keys()):
            years = data[ward][category]

            row_2023 = years.get(2023)
            row_2024 = years.get(2024)

            allocated_2023 = row_2023["allocated"] if row_2023 else None
            spent_2023     = row_2023["spent"]     if row_2023 else None
            allocated_2024 = row_2024["allocated"] if row_2024 else None
            spent_2024     = row_2024["spent"]     if row_2024 else None

            # Growth calculation — only if both years present
            if allocated_2023 is not None and allocated_2024 is not None:
                pct_growth = round(
                    ((allocated_2024 - allocated_2023) / allocated_2023) * 100,
                    2
                )
                flag = "budget_cut" if pct_growth < 0 else ""
            else:
                pct_growth = "N/A"
                flag = "data_missing"

            # Utilisation 2023 — only if 2023 present and allocated > 0
            if allocated_2023 is not None and allocated_2023 > 0 and spent_2023 is not None:
                utilisation_2023 = round((spent_2023 / allocated_2023) * 100, 2)
            else:
                utilisation_2023 = "N/A"

            results.append({
                "ward":            ward,
                "category":        category,
                "allocated_2023":  int(allocated_2023) if allocated_2023 is not None else "N/A",
                "spent_2023":      int(spent_2023)     if spent_2023     is not None else "N/A",
                "allocated_2024":  int(allocated_2024) if allocated_2024 is not None else "N/A",
                "spent_2024":      int(spent_2024)     if spent_2024     is not None else "N/A",
                "pct_growth":      pct_growth,
                "utilisation_2023": utilisation_2023,
                "flag":            flag,
            })

    return results


def write_output(results: list, filepath: str):
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        writer.writerows(results)


def print_summary(results: list):
    total       = len(results)
    cuts        = sum(1 for r in results if r["flag"] == "budget_cut")
    missing     = sum(1 for r in results if r["flag"] == "data_missing")
    avg_growth  = [r["pct_growth"] for r in results if isinstance(r["pct_growth"], float)]
    avg         = round(sum(avg_growth) / len(avg_growth), 2) if avg_growth else "N/A"

    print(f"\n── Budget Growth Summary ──────────────────────────")
    print(f"  Ward+Category pairs analysed : {total}")
    print(f"  Budget cuts (2024 < 2023)    : {cuts}")
    print(f"  Missing year data            : {missing}")
    print(f"  Average % growth (computed)  : {avg}%")

    # Top 3 growth
    sorted_rows = sorted(
        [r for r in results if isinstance(r["pct_growth"], float)],
        key=lambda x: x["pct_growth"], reverse=True
    )
    print("\n  Top 3 budget increases:")
    for r in sorted_rows[:3]:
        print(f"    {r['ward']} / {r['category']}: +{r['pct_growth']}%")

    print("\n  Worst utilisation 2023 (overspend/underspend):")
    util_rows = sorted(
        [r for r in results if isinstance(r["utilisation_2023"], float)],
        key=lambda x: abs(x["utilisation_2023"] - 100), reverse=True
    )
    for r in util_rows[:3]:
        print(f"    {r['ward']} / {r['category']}: {r['utilisation_2023']}%")


def run():
    print(f"Loading budget data from: {INPUT_FILE}")
    data = load_budget_data(INPUT_FILE)
    print(f"Loaded data for {len(data)} wards.")

    print("Computing per-ward per-category growth metrics...")
    results = compute_growth(data)

    write_output(results, OUTPUT_FILE)
    print(f"\n✓ Results written to: {OUTPUT_FILE}")
    print_summary(results)


if __name__ == "__main__":
    run()
