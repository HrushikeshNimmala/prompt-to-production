# UC-0B: Summary That Changes Meaning — skills.md

## Skill: summarise_policy

### What this skill does
Reads a policy document text file and produces a structured plain-English summary that preserves all obligations, numbers, deadlines, and penalties — without adding, removing, or distorting any clause.

### Input
- `policy_text` (str): The full text of the policy document.
- `output_filename` (str): Path to write the summary text file.

### Output
A `.txt` file with:
- Document title and version at the top.
- One section per numbered heading in the original document.
- Under each section: bullet points covering all sub-clauses.
- Exact numbers preserved (e.g., "26 weeks", "INR 5,000", "30 days").
- A "Key Obligations" block at the end listing must-do items for employees.
- A "Penalties" block at the end listing all consequences of violations.

### Common failure modes this skill prevents

| Failure | Prevention rule |
|---------|----------------|
| Clause omission | Every numbered section must be present |
| Number distortion | Copy numbers verbatim; never round or approximate |
| Merging leave types | Each leave type gets its own bullet group |
| Adding unsupported claims | Only information from source document allowed |
| Vague penalty language | Copy exact penalty wording from source |

### CRAFT test checklist
- [ ] Count numbered sections in source → same count in output
- [ ] Pick 3 random numbers from source → verify exact match in output
- [ ] Confirm penalties section is present
- [ ] Confirm no information appears in summary that is absent from source
- [ ] Output file is non-empty and readable
