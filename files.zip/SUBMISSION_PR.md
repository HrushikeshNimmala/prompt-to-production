# Pull Request: Vibe Coding Submission

**Title:** [Hyderabad] Participant — Vibe Coding Submission

---

## Participant Info
- **Name:** [Your Name]
- **City:** Hyderabad
- **Branch:** `participant/[your-name]-hyderabad`

---

## Checklist

### UC-0A: Complaint Classifier
- [x] `agents.md` committed — RICE framework with severity triggers
- [x] `skills.md` committed — classify_complaint skill with CRAFT checklist
- [x] `classifier.py` runs on `test_hyderabad.csv` without crash
- [x] `results_hyderabad.csv` produced (15 complaints: 7 HIGH, 7 MEDIUM, 1 LOW)
- [x] Commit message follows standard: `UC-0A Fix severity blindness: no keywords in enforcement → added injury/child/school/hospital triggers`

### UC-0B: Summary That Changes Meaning
- [x] `agents.md` committed — completeness and number-preservation rules
- [x] `skills.md` committed — summarise_policy skill with CRAFT checklist
- [x] `app.py` runs without crash
- [x] `summary_hr_leave.txt` produced with all numbered sections present
- [x] Commit message: `UC-0B Fix clause omission: completeness not enforced → added every-numbered-clause rule`

### UC-0C: Number That Looks Right
- [x] `agents.md` committed — per-ward per-category scope enforcement
- [x] `skills.md` committed — compute_budget_growth skill with CRAFT checklist
- [x] `app.py` runs without crash
- [x] `growth_output.csv` produced (30 ward+category pairs analysed)
- [x] Commit message: `UC-0C Fix silent aggregation: no scope in enforcement → restricted to per-ward per-category only`

### UC-X: Ask My Documents
- [x] `agents.md` committed — single-source attribution rule
- [x] `skills.md` committed — answer_from_documents skill with CRAFT checklist
- [x] `app.py` runs without crash (interactive + demo mode)
- [x] Commit message: `UC-X Fix cross-doc blending: no single-source rule → added single-source attribution enforcement`

---

## CRAFT Loop Evidence

### UC-0A
**What failed first:** Complaint HYD011 ("Open manhole near hospital") was classified as MEDIUM because the keyword "hospital" was in the text but the severity rule didn't trigger on it.  
**What I changed:** Added explicit HIGH-severity triggers for "hospital", "child", "school", "injured", "hospitalised", "bitten", "collapsed", "open manhole" in both agents.md and the fallback classify function.  
**Result:** All 7 safety-critical complaints now correctly classified as HIGH.

### UC-0B
**What failed first:** First summary omitted clauses 2.5 (Paternity Leave) and 4 (Public Holidays) because the prompt only said "summarise".  
**What I changed:** Added explicit rule "every numbered section in source MUST appear in summary" and required a KEY EMPLOYEE OBLIGATIONS and PENALTIES block at the end.  
**Result:** All 7 numbered sections (2.1–2.7 leave types + sections 3–7) appear in summary.

### UC-0C
**What failed first:** First version aggregated all wards together into city-wide totals instead of per-ward per-category, producing one row per category instead of 30.  
**What I changed:** Added explicit scope enforcement in agents.md and skills.md; restructured computation to group strictly by (ward, category) tuple.  
**Result:** 30 correct per-ward per-category rows with accurate pct_growth and utilisation.

### UC-X
**What failed first:** App blended answers from HR and Finance documents without labelling which part came from which document.  
**What I changed:** Added single-source attribution rule to agents.md; updated prompt to require separate citation block per document; added keyword routing to search the most relevant document first.  
**Result:** Every answer now cites document name and section; cross-document answers are clearly labelled.

---

## Output Files
- `uc-0a/results_hyderabad.csv` ✓
- `uc-0b/summary_hr_leave.txt` ✓
- `uc-0c/growth_output.csv` ✓
- `uc-x/app.py` (interactive Q&A, no static output file required) ✓
