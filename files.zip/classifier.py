"""
UC-0A: Complaint Classifier
Reads test_hyderabad.csv, classifies each complaint using Claude API,
and writes results_hyderabad.csv with category, severity, and routing_note columns.

Commit: UC-0A Fix severity blindness: no injury/child keywords in enforcement → added
        injury/child/school/hospital/collapsed triggers to force HIGH severity.
"""

import csv
import json
import re
import sys
import time

try:
    import urllib.request
    import urllib.error
except ImportError:
    print("ERROR: urllib not available")
    sys.exit(1)

# ── Configuration ──────────────────────────────────────────────────────────────
INPUT_FILE  = "data/city-test-files/test_hyderabad.csv"
OUTPUT_FILE = "uc-0a/results_hyderabad.csv"
MODEL       = "claude-sonnet-4-20250514"
API_URL     = "https://api.anthropic.com/v1/messages"

SYSTEM_PROMPT = """You are a civic complaint classifier for GHMC (Greater Hyderabad Municipal Corporation).

Given a complaint text, return ONLY a JSON object with exactly these three keys:
- "category": one of [Roads, Sanitation, Water, Electricity, Infrastructure, Safety, Public Spaces, Health]
- "severity": one of [HIGH, MEDIUM, LOW]
- "routing_note": one sentence naming the responsible department and reason

SEVERITY RULES (strictly enforced):
- HIGH: complaint mentions injury, hospitalised, bitten, attacked, child, children, student, school,
        hospital, collapsed, open manhole, near miss, almost hit, or any imminent physical danger.
- MEDIUM: service failure lasting >5 days (garbage, broken lights, irregular water, fallen tree,
          pothole, illegal construction) with no life-safety signals.
- LOW: cosmetic issues, general inconvenience, minor requests.

Return ONLY valid JSON. No preamble, no explanation, no markdown fences."""

USER_TEMPLATE = "Classify this complaint:\n\n{complaint_text}"


def call_claude(complaint_text: str) -> dict:
    """Call Claude API and return parsed JSON result."""
    payload = {
        "model": MODEL,
        "max_tokens": 300,
        "system": SYSTEM_PROMPT,
        "messages": [
            {"role": "user", "content": USER_TEMPLATE.format(complaint_text=complaint_text)}
        ]
    }

    req = urllib.request.Request(
        API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            raw_text = data["content"][0]["text"].strip()
            # Strip markdown fences if present
            raw_text = re.sub(r"^```json\s*", "", raw_text)
            raw_text = re.sub(r"\s*```$", "", raw_text)
            return json.loads(raw_text)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8")
        print(f"  HTTP Error {e.code}: {body[:200]}")
        return fallback_classify(complaint_text)
    except Exception as ex:
        print(f"  API error: {ex}")
        return fallback_classify(complaint_text)


def fallback_classify(complaint_text: str) -> dict:
    """
    Rule-based fallback if API is unavailable.
    Ensures HIGH-risk complaints are never silently downgraded.
    """
    text = complaint_text.lower()

    # Severity detection
    high_triggers = [
        "injur", "hospitalised", "hospitalized", "bitten", "attack",
        "child", "student", "school", "hospital", "collapsed",
        "open manhole", "almost hit", "near miss", "dangerous", "death"
    ]
    severity = "LOW"
    if any(t in text for t in high_triggers):
        severity = "HIGH"
    elif any(t in text for t in ["days", "weeks", "overflow", "broken", "pothole",
                                   "garbage", "irregular", "fallen", "bribe", "illegal"]):
        severity = "MEDIUM"

    # Category detection
    category_map = {
        "Roads":         ["road", "pothole", "traffic", "car", "vehicle", "bus stop"],
        "Sanitation":    ["garbage", "waste", "sewage", "drain", "smell"],
        "Water":         ["water", "tanker", "supply", "pipe"],
        "Electricity":   ["electricity", "light", "power", "meter", "connection"],
        "Infrastructure":["manhole", "tree", "construction", "shelter", "street"],
        "Safety":        ["dog", "stray", "attack", "bitten", "speed", "hit"],
        "Public Spaces": ["park", "garden", "bench", "playground"],
        "Health":        ["dengue", "mosquito", "disease", "fever"],
    }
    category = "Infrastructure"
    for cat, keywords in category_map.items():
        if any(k in text for k in keywords):
            category = cat
            break

    routing_map = {
        "Roads": "Roads & Transport dept — pothole/road maintenance required.",
        "Sanitation": "Sanitation dept — garbage/sewage clearance needed.",
        "Water": "HMWS&SB — water supply restoration required.",
        "Electricity": "TSSPDCL — electrical issue resolution required.",
        "Infrastructure": "Engineering dept — structural repair/inspection required.",
        "Safety": "Animal Control / Traffic Police — safety hazard resolution required.",
        "Public Spaces": "Parks & Recreation dept — maintenance required.",
        "Health": "Public Health dept — disease vector control required.",
    }

    return {
        "category": category,
        "severity": severity,
        "routing_note": routing_map.get(category, "Civic dept — general resolution required.")
    }


def run():
    print(f"Reading complaints from: {INPUT_FILE}")
    results = []

    with open(INPUT_FILE, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    print(f"Processing {len(rows)} complaints...\n")

    for i, row in enumerate(rows, 1):
        cid = row.get("id", f"ROW{i}")
        text = row.get("complaint_text", "").strip()
        ward = row.get("ward", "")
        print(f"[{i}/{len(rows)}] {cid}: {text[:60]}...")

        classification = call_claude(text)

        results.append({
            "id":           cid,
            "ward":         ward,
            "complaint_text": text,
            "category":     classification.get("category", "Infrastructure"),
            "severity":     classification.get("severity", "MEDIUM"),
            "routing_note": classification.get("routing_note", ""),
        })

        time.sleep(0.5)  # avoid rate limiting

    # Write output
    fieldnames = ["id", "ward", "complaint_text", "category", "severity", "routing_note"]
    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    print(f"\n✓ Results written to: {OUTPUT_FILE}")
    print(f"  Total: {len(results)} | HIGH: {sum(1 for r in results if r['severity']=='HIGH')} "
          f"| MEDIUM: {sum(1 for r in results if r['severity']=='MEDIUM')} "
          f"| LOW: {sum(1 for r in results if r['severity']=='LOW')}")


if __name__ == "__main__":
    run()
