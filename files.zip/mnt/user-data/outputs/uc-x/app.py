"""
UC-X: Ask My Documents
Interactive Q&A over policy documents (HR Leave, IT Acceptable Use, Finance Reimbursement).
Uses Claude API to answer questions from document content only — no invention.

Commit: UC-X Fix cross-doc blending: no single-source rule → added single-source attribution
        enforcement and explicit "not covered" response for out-of-scope questions.
"""

import json
import os
import sys
import urllib.request
import urllib.error

# ── Configuration ──────────────────────────────────────────────────────────────
POLICY_DIR = "data/policy-documents"
MODEL      = "claude-sonnet-4-20250514"
API_URL    = "https://api.anthropic.com/v1/messages"

POLICY_FILES = {
    "HR Leave Policy":             "policy_hr_leave.txt",
    "IT Acceptable Use Policy":    "policy_it_acceptable_use.txt",
    "Finance Reimbursement Policy": "policy_finance_reimbursement.txt",
}

SYSTEM_PROMPT = """You are a policy Q&A agent for an enterprise compliance team.

You will be given the full text of policy documents followed by an employee question.

STRICT RULES:
1. Answer ONLY from the provided documents. Never invent or guess.
2. Every answer must include a citation: "Source: [Document Name], Section [X.Y]"
3. If the answer spans multiple documents, address each one separately with its own citation.
4. SINGLE-SOURCE RULE: Do not blend clauses from different documents into one statement without labelling them.
5. If a question is not covered in any document, respond ONLY with: "This is not covered in the available policy documents."
6. Copy numbers verbatim (days, amounts, percentages). Never approximate.
7. Do NOT state that an employee is entitled to something not explicitly in the policy.

Format your answer as:
ANSWER: [plain English answer]
SOURCE: [Document Name], Section [X.Y]"""


def load_documents() -> dict:
    docs = {}
    for doc_name, filename in POLICY_FILES.items():
        filepath = os.path.join(POLICY_DIR, filename)
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                docs[doc_name] = f.read()
            print(f"  ✓ Loaded: {doc_name}")
        except FileNotFoundError:
            print(f"  ✗ Missing: {filepath}")
    return docs


def build_context(docs: dict) -> str:
    parts = []
    for name, text in docs.items():
        parts.append(f"=== DOCUMENT: {name} ===\n{text}\n")
    return "\n".join(parts)


def call_claude(question: str, doc_context: str) -> str:
    user_content = f"{doc_context}\n\n--- EMPLOYEE QUESTION ---\n{question}"
    payload = {
        "model": MODEL,
        "max_tokens": 800,
        "system": SYSTEM_PROMPT,
        "messages": [
            {"role": "user", "content": user_content}
        ]
    }
    req = urllib.request.Request(
        API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["content"][0]["text"].strip()
    except urllib.error.HTTPError as e:
        return f"[API Error {e.code}]: {e.read().decode()[:200]}"
    except Exception as ex:
        return None


def keyword_route(question: str, docs: dict) -> dict:
    """
    Fallback: route question to relevant doc(s) based on keywords.
    Returns subset of docs most relevant to the question.
    """
    q = question.lower()
    leave_kw   = ["leave", "sick", "vacation", "maternity", "paternity", "holiday", "absent", "absence", "casual", "earned"]
    it_kw      = ["laptop", "email", "internet", "password", "usb", "software", "device", "data", "phone", "byod", "monitoring"]
    finance_kw = ["expense", "reimburse", "travel", "hotel", "taxi", "food", "receipt", "claim", "allowance", "advance", "mileage"]

    matched = {}
    if any(k in q for k in leave_kw):
        for n, t in docs.items():
            if "Leave" in n:
                matched[n] = t
    if any(k in q for k in it_kw):
        for n, t in docs.items():
            if "IT" in n:
                matched[n] = t
    if any(k in q for k in finance_kw):
        for n, t in docs.items():
            if "Finance" in n or "Reimbursement" in n:
                matched[n] = t

    return matched if matched else docs  # fall back to all docs


def fallback_answer(question: str, docs: dict) -> str:
    """
    Simple keyword search fallback when API is unavailable.
    Finds paragraphs containing question keywords from relevant documents.
    """
    relevant_docs = keyword_route(question, docs)
    q_words = [w for w in question.lower().split() if len(w) > 3]

    hits = []
    for doc_name, text in relevant_docs.items():
        paragraphs = text.split("\n")
        for i, para in enumerate(paragraphs):
            if any(w in para.lower() for w in q_words):
                # Get context: this line + 1 more
                snippet = " ".join(paragraphs[i:i+2]).strip()
                if snippet:
                    hits.append((doc_name, snippet))

    if not hits:
        return "This is not covered in the available policy documents."

    response_lines = ["ANSWER: Based on the policy documents:\n"]
    for doc_name, snippet in hits[:3]:
        response_lines.append(f"  • {snippet}")
        response_lines.append(f"    SOURCE: {doc_name}\n")

    return "\n".join(response_lines)


def run_interactive(docs: dict):
    doc_context = build_context(docs)
    print("\n" + "="*60)
    print("UC-X: Ask My Documents — Policy Q&A")
    print("Type your question. Type 'quit' to exit.")
    print("="*60 + "\n")

    sample_questions = [
        "How many days of maternity leave am I entitled to for my first child?",
        "Can I use a personal USB drive on my work laptop?",
        "What is the maximum hotel reimbursement in Hyderabad?",
        "Can casual leave be carried forward to the next year?",
        "What happens if I submit an expense claim after 60 days?",
    ]

    print("Sample questions to try:")
    for i, q in enumerate(sample_questions, 1):
        print(f"  {i}. {q}")
    print()

    while True:
        try:
            question = input("Your question: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            break

        if question.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break
        if not question:
            continue

        print("\nSearching documents...")
        answer = call_claude(question, doc_context)
        if not answer:
            print("[API unavailable — using keyword fallback]")
            answer = fallback_answer(question, docs)

        print(f"\n{answer}\n")
        print("-" * 60)


def run_demo(docs: dict):
    """Run pre-set demo questions and print answers."""
    doc_context = build_context(docs)

    demo_qs = [
        "How many days of maternity leave am I entitled to?",
        "Can I use a personal USB drive on my work laptop?",
        "What is the maximum hotel reimbursement per night in Hyderabad?",
        "Can casual leave be carried forward to next year?",
        "Can I claim alcohol under client entertainment expenses?",
    ]

    print("\n" + "="*60)
    print("UC-X: Ask My Documents — DEMO MODE")
    print("="*60)

    for q in demo_qs:
        print(f"\nQ: {q}")
        print("-" * 40)
        answer = call_claude(q, doc_context)
        if not answer:
            answer = fallback_answer(q, docs)
        print(answer)
        print()


def run():
    print("Loading policy documents...")
    docs = load_documents()

    if not docs:
        print("ERROR: No documents loaded. Check data/policy-documents/ directory.")
        sys.exit(1)

    print(f"\n{len(docs)} documents loaded.\n")

    # Check if running interactively or in demo mode
    if sys.stdin.isatty():
        run_interactive(docs)
    else:
        run_demo(docs)


if __name__ == "__main__":
    run()
