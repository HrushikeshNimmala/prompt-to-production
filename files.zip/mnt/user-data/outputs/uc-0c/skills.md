# UC-0C: Number That Looks Right — skills.md

## Skill: compute_budget_growth

### What this skill does
Reads `ward_budget.csv`, computes per-ward per-category year-over-year budget growth and utilisation, and writes `growth_output.csv`.

### Input
- `budget_csv_path` (str): Path to the ward_budget.csv file.
- `output_csv_path` (str): Path to write growth_output.csv.

### Output columns in growth_output.csv
| Column | Description |
|--------|-------------|
| ward | Ward name |
| category | Budget category |
| allocated_2023 | Allocated budget in 2023 (INR) |
| allocated_2024 | Allocated budget in 2024 (INR) |
| spent_2023 | Spent budget in 2023 (INR) |
| pct_growth | Year-over-year growth in allocation (%) |
| utilisation_2023 | Spend as % of allocation in 2023 (%) |
| flag | "budget_cut" if 2024 < 2023, "data_missing" if either year absent, else "" |

### Computation rules (strictly enforced)
1. **Scope**: compute per ward + category pair only. No cross-ward or cross-category aggregation.
2. **Growth formula**: `((allocated_2024 - allocated_2023) / allocated_2023) * 100`
3. **Utilisation formula**: `(spent_2023 / allocated_2023) * 100`
4. **Rounding**: exactly 2 decimal places for both metrics.
5. **Missing data**: if either year is absent for a pair, set pct_growth = "N/A", flag = "data_missing".
6. **Budget cut flag**: if pct_growth < 0, set flag = "budget_cut".
7. **No imputation**: never fill missing values with 0 or averages.

### Common failure modes this skill prevents

| Failure | Prevention |
|---------|-----------|
| Silent aggregation across wards | Strict per-ward per-category grouping |
| Confusing spent with allocated | Column names validated before computation |
| Missing-year imputation | Explicit data_missing flag instead of 0 |
| Wrong rounding | round(..., 2) applied to final values only |
| Inventing data | Only source CSV values used |

### CRAFT test checklist
- [ ] Pick one ward+category → manually verify pct_growth formula
- [ ] Confirm no row contains an invented number
- [ ] Confirm "budget_cut" flag appears where allocated_2024 < allocated_2023
- [ ] Confirm "data_missing" for any ward with only one year of data
- [ ] Output file opens without errors and has expected column count
