# UC-X: Ask My Documents — skills.md

## Skill: answer_from_documents

### What this skill does
Takes a natural-language employee question and a set of loaded policy documents, retrieves the relevant clauses, and returns a precise, source-attributed answer.

### Input
- `question` (str): The employee's question in plain English.
- `documents` (dict): A dictionary mapping document names to their full text content.

### Output
A plain-text response containing:
- Direct answer to the question.
- Citation: "Source: [Document Name], Section [X.Y]"
- If multiple documents are relevant, each is addressed separately with its own citation.
- If not found: "This is not covered in the available policy documents."

### Routing logic
The skill automatically routes questions to the right document based on keywords:

| Keywords in question | Document to search first |
|---------------------|-------------------------|
| leave, vacation, sick, maternity, paternity, holiday, absence | policy_hr_leave |
| laptop, email, internet, password, USB, software, device, data | policy_it_acceptable_use |
| expense, reimbursement, travel, hotel, taxi, food, receipt, claim | policy_finance_reimbursement |
| All others | Search all documents |

### Single-source attribution rule
If the answer is found in Document A, do NOT add commentary from Document B unless the question explicitly spans both. Blending document content without attribution is a failure mode.

### CRAFT test checklist
- [ ] Ask a question about maternity leave → answer cites HR Leave policy section
- [ ] Ask a question about USB drives → answer cites IT policy section
- [ ] Ask about a topic not in any document → response says "not covered"
- [ ] All numbers in answer match source document exactly
- [ ] No answer claims entitlement that isn't explicitly stated in the policy
